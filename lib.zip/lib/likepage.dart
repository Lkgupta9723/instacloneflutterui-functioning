import 'package:flutter/material.dart';

class Likesceen extends StatefulWidget {
  const Likesceen({super.key});

  @override
  State<Likesceen> createState() => _LikesceenState();
}

class _LikesceenState extends State<Likesceen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Like Screen'),),);
  }
}