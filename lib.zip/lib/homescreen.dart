// ignore_for_file: sort_child_properties_last

import 'package:flutter/material.dart';
import 'package:instagramclone/messager.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> story = [
    {
      'Userimage':
          'https://plus.unsplash.com/premium_photo-1674507923625-90409acdb8d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'veer'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1650110002977-3ee8cc5eac91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1937&q=80',
      'Username': 'Ramesh'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1665574435997-b0d77cede9ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'Ram'
    },
    {
      'Userimage':
          'https://plus.unsplash.com/premium_photo-1674507923625-90409acdb8d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'veer'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1650110002977-3ee8cc5eac91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1937&q=80',
      'Username': 'Ramesh'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1665574435997-b0d77cede9ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'Ram'
    },
    {
      'Userimage':
          'https://plus.unsplash.com/premium_photo-1674507923625-90409acdb8d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'veer'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1650110002977-3ee8cc5eac91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1937&q=80',
      'Username': 'Ramesh'
    },
    {
      'Userimage':
          'https://images.unsplash.com/photo-1665574435997-b0d77cede9ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
      'Username': 'Ram'
    },
  ];
  // List<Map<String, dynamic>> post = [
  //   {
  //     ''
  //   }
  // ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: PreferredSize(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    width: 12,
                  ),
                  InkWell(
                    onTap: () {},
                    child: Image.asset(
                      'assets/icons/Camera.png',
                      height: 22,
                      width: 24,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(
                    width: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Image.asset(
                      'assets/Instagramlogo.png',
                      height: 35,
                    ),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {},
                    child: Image.asset(
                      'assets/icons/TV.png',
                      height: 25,
                      width: 24,
                    ),
                  ),
                  const SizedBox(
                    width: 18,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const Messanger()));
                    },
                    child: Image.asset(
                      'assets/icons/Messanger.png',
                      height: 20,
                      width: 23,
                    ),
                  ),
                  const SizedBox(
                    width: 12,
                  ),
                ],
              ),
              preferredSize: const Size(double.infinity, 44)),
          body: ListView(
            scrollDirection: Axis.vertical,
            children: [
              const Divider(),
              SizedBox(
                height: 90,
                width: double.infinity,
                child: ListView.builder(
                  itemCount: story.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          child: Container(
                            height: 68,
                            width: 68,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                  colors: [
                                    Color(0xffFBAA47),
                                    Color(0xffD91A46),
                                    Color(0xffA60f93),
                                  ],
                                  begin: Alignment.bottomLeft,
                                  end: Alignment.topRight),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(2),
                              child: Container(
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(2),
                                  child: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage(story[index]['Userimage']),
                                    radius: 28,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Text(
                          story[index]['Username'],
                          style: const TextStyle(
                              fontFamily: 'SFProText',
                              fontWeight: FontWeight.w400,
                              fontSize: 12),
                        ),
                      ],
                    );
                  },
                ),
              ),
              const Divider(),
            ],
          )),
    );
  }
}
